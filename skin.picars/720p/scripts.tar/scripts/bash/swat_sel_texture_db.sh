#!/bin/bash


sqlite3 /home/pi/.xbmc/userdata/Database/Textures13.db "SELECT cachedurl FROM texture"
