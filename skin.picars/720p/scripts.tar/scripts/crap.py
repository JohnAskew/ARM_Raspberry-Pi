import xbmc, xbmcgui
xbmc.executebuiltin("Notification(ATTENTION, System Shut Down, 10000,/home/osmc/.kodi/addons/skin.picars/lcars/shut/An_Redalert02.gif)")
xbmc.playSFX('/home/osmc/.kodi/addons/skin.picars/lcars/wav/offline.wav')
