import xbmc, time
time.sleep(1)
if  not xbmc.Player().isPlaying() :
    xbmc.executebuiltin("PlayMedia(/home/osmc/.kodi/addons/skin.picars/lcars/wav/home/main_videos.mp3)")
