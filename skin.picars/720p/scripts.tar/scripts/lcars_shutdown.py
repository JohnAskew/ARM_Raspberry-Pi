import xbmc, xbmcgui
xbmc.executebuiltin("Notification(ATTENTION, System Shut Down, 10000,/home/osmc/.kodi/addons/skin.picars/lcars/shut/red_alert.gif)")
xbmc.playSFX('/home/osmc/.kodi/addons/skin.picars/lcars/wav/offline.wav')
