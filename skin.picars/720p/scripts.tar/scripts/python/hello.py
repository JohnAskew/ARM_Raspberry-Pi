#!/usr/bin/env python
# Was #!/usr/bin/python
# hello.py - #=comment line
#	Notes: case sensitive
#	#!/usr/bin/python is abs. path - equates to c:\python\python.exe

print 'Hello world!'
print 'I am ', 6 * 2, 'years old'
# -- Variables --#
i = 1
s = 'hello world!'
i + 1
(i + 2) * 10
s.upper()
print s, i
print s.upper()
i= 74.99
i = 'now I am a string'
