#!/usr/bin/python
# lab1.py

name = 'John Public'
print 'Hi, my name is ' + name
