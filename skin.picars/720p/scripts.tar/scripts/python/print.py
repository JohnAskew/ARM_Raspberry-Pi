#!/usr/bin/python
#! print.py

name = 'John Cleese'
print name
print ' is a funny guy'
print name, 
print 'is a funny guy'
