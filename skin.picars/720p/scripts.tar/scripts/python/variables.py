#!/usr/bin/python
# variables.py

name1 = 'Eric Idle'
name2 = 'John Cleese'
print 'two of my favorite Monty Python actors are:'
print name1 + ' and ' + name2
print
i=3
j=12
print 'two of my favorite numbers are: '
print 1, 'and ', j
