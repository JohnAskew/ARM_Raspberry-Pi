import xbmc, time
# Change Control-------------------------------------#
# Askew20150329 Remove first mp3..too long           #
#----------------------------------------------------#
if  not xbmc.Player().isPlaying() :
    #Askew20150329 xbmc.executebuiltin("PlayMedia(/home/osmc/.kodi/addons/skin.picars/lcars/wav/settings/lcars_system_calibrationlockeddiagnosticunderway.mp3)")
    #Askew20150329 time.sleep(5.5)
    xbmc.executebuiltin("PlayMedia(/home/osmc/.kodi/addons/skin.picars/lcars/wav/settings/lcars_lcars_diagnostics_complete.wav)")
    time.sleep(2.0) # Askew20150329 - was 2.5
    xbmc.executebuiltin("PlayMedia(/home/osmc/.kodi/addons/skin.picars/lcars/wav/lcars_heartbeats.mp3)")
