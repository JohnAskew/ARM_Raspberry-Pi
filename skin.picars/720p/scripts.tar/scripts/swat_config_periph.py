#!/usr/bin/env python
import xbmc, xbmcgui
xbmc.executebuiltin("ActivateWindowAndFocus(10150,1,1)")
