import xbmc
xbmc.executebuiltin("Notification( Informational, Click to change Display/Audio/Other settings , 2000, /home/osmc/.kodi/addons/skin.picars/lcars/warn/green.gif )")
