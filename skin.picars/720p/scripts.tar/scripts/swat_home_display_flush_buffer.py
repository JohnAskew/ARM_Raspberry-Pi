import xbmc
xbmc.executebuiltin("Notification( Informational, Click to run XBMC Maint. Tool \"Clear Cache\" , 2000, /home/osmc/.kodi/addons/skin.picars/lcars/warn/green.gif )")
