import xbmc
xbmc.executebuiltin("Notification( Informational, Click to MUTE; click again sets Vol. at 85% ,2000, /home/osmc/.kodi/addons/skin.picars/lcars/warn/green.gif )")
