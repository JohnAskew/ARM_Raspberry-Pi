import xbmc
xbmc.executebuiltin("Notification( Informational, Settings - How TV/HDMI/CEC interact with LCARS device, 2000, /home/osmc/.kodi/addons/skin.picars/lcars/warn/green.gif )")
