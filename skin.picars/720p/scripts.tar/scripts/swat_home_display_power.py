import xbmc
xbmc.executebuiltin("Notification( Caution Advised!, Launch System Shutdown Menu ,2000, /home/osmc/.kodi/addons/skin.picars/lcars/warn/bluealert.gif )")
