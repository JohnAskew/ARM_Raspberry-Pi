import xbmc
xbmc.executebuiltin("Notification( Informational, Click to set  VOLUME-->50%  ,2000, /home/osmc/.kodi/addons/skin.picars/lcars/warn/green.gif )")
