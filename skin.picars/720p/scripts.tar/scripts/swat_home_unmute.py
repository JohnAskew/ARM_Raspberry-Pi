import xbmc
xbmc.executebuiltin("Mute")
xbmc.executebuiltin("SetVolume(85,0)")
xbmc.executebuiltin("Notification(Completed,Volume Manipulation,2000,/home/osmc/.kodi/addons/skin.picars/lcars/warn/orange.gif)")
