#!/usr/bin/env python
import xbmc, xbmcgui
xbmc.executebuiltin("ActivateWindowAndFocus(10016,1,1)")
